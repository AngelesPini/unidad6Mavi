#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace sf;

int main()
{

    RenderWindow App(VideoMode(800, 600), "Space");

    
    Vector2f position(100.0f, 100.0f);
    Vector2f velocity(0.0f, 0.0f); 
    const float acceleration = 0.1f;   
    const float friction = 0.05f;       
    bool isMovingLeft = false;
    bool isMovingRight = false;

    
    while (App.isOpen())
    {
        Event event;
        while (App.pollEvent(event))
        {
            if (event.type == Event::Closed)
                App.close();

            if (event.type == Event::KeyPressed)
            {
                if (event.key.code == Keyboard::Left)
                {
                    isMovingLeft = true;
                    isMovingRight = false;
                }
                else if (event.key.code == Keyboard::Right)
                {
                    isMovingRight = true;
                    isMovingLeft = false;
                }
            }
            else if (event.type == Event::KeyReleased)
            {
                if (event.key.code == Keyboard::Left || event.key.code == Keyboard::Right)
                {
                    isMovingLeft = false;
                    isMovingRight = false;
                }
            }
        }


        float deltaTime = 1.0f / 60.0f; 

        if (isMovingLeft)
            velocity.x -= acceleration * deltaTime;
        else if (isMovingRight)
            velocity.x += acceleration * deltaTime;
        else
            velocity.x -= (velocity.x * friction);


        position += velocity * deltaTime;


        if (position.x > App.getSize().x)
            position.x = 0.0f;
        else if (position.x < 0.0f)
            position.x = App.getSize().x;

        if (position.y > App.getSize().y)
            position.y = 0.0f;
        else if (position.y < 0.0f)
            position.y = App.getSize().y;


        App.clear();


        CircleShape object(25.0f); 
        object.setPosition(position);
        object.setFillColor(Color::Red);
        App.draw(object);

        App.display();
    }

    return 0;
}
