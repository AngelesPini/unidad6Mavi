#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <vector>
#include <ctime>
#include <cstdlib>

using namespace sf;
/*clase enemigo*/
class Enemigo {
public:
    Enemigo(Texture& texture, float scale, bool isMRUV)
        : isMRUV(isMRUV), acceleration(0.0001f), velocity(0.1f), tiempoVida(Clock()), vivo(true) {
        sprite.setTexture(texture);
        sprite.setScale(scale, scale);
        sprite.setPosition(rand() % 800, rand() % 600);
    }

    void update() {
        if (vivo) {
            if (isMRUV) {
                // Movimiento MRUV
                velocity += acceleration;
                sprite.move(velocity, 0.0f);
            }
            else {
                // Movimiento MRU
                sprite.move(velocity, 0.0f);
            }

            if (tiempoVida.getElapsedTime().asSeconds() > 1.5) {
                vivo = false;
            }
        }
    }
    Sprite sprite;
    bool vivo;
    Clock tiempoVida;
    bool isMRUV;
    float acceleration;
    float velocity;
};

int main()
{
    srand(time(0));

    Texture texture;
    Texture cursorTexture;

    int puntos = 0;
    /*textos*/
    Font font;
    Text texto;
    font.loadFromFile("Oswald-SemiBold.ttf");

    texto.setFont(font);
    texto.setCharacterSize(24);
    texto.setFillColor(Color::White);
    texto.setString("Puntos: " + std::to_string(puntos));
    texto.setPosition(100, 600);

    /*texturas*/
    texture.loadFromFile("et.png");
    cursorTexture.loadFromFile("crosshair.png");

    RenderWindow App(VideoMode(1200, 800, 32), "wildPhysics");
    App.setMouseCursorVisible(false);

    Sprite cursorSprite(cursorTexture);
    cursorSprite.setScale(0.3f, 0.3f);
    cursorSprite.setOrigin(cursorSprite.getGlobalBounds().width / 2, cursorSprite.getGlobalBounds().height / 2);
    std::vector<Enemigo> enemigos;

    Clock enemigoAparecer;
    Time enemigoDesaparecer = seconds(1);

    while (App.isOpen()) {
        Event event;
        while (App.pollEvent(event)) {
            if (event.type == Event::Closed) {
                App.close();
            }
            else if (event.type == Event::MouseMoved) {
                cursorSprite.setPosition(event.mouseMove.x, event.mouseMove.y);
            }
            else if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                for (Enemigo& enemigo : enemigos) {
                    if (enemigo.vivo && enemigo.sprite.getGlobalBounds().contains(cursorSprite.getPosition())) {
                        enemigo.vivo = false;
                        puntos++;
                    }
                    texto.setString("Puntos: " + std::to_string(puntos));
                }
            }
        }

 
        if (enemigoAparecer.getElapsedTime() >= enemigoDesaparecer) {
            enemigos.emplace_back(texture, 0.1f, false);
            enemigos.emplace_back(texture, 0.1f, true);
            enemigoAparecer.restart();
        }

        App.clear();
        App.draw(texto);

        for (Enemigo& enemigo : enemigos) {
            if (enemigo.vivo) {
                enemigo.update();
                App.draw(enemigo.sprite);
            }
        }

        App.draw(cursorSprite);
        App.display();

    }

    return 0;
}
/*recicl� todo mi codigo "clickale" y lo adapt� para cumplir con la consigna */