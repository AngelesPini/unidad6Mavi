#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace sf;

int main()
{
    RenderWindow App(VideoMode(800, 600), "Bounce");

    Vector2f position(400.0f, 100.0f);
    Vector2f velocity(0.0f, 0.0f);

    const float gravity = 0.000098f;

    const float bounceFactor = 0.8f;


    while (App.isOpen())
    {
        Event event;
        while (App.pollEvent(event))
        {
            if (event.type == Event::Closed)
                App.close();
        }

        velocity.y += gravity;

        position += velocity;

        if (position.y > 600.0f)
        {
            
            position.y = 600.0f; 
            velocity.y = -velocity.y * bounceFactor; 
        }

        App.clear();

        CircleShape ball(20.0f);
        ball.setFillColor(Color::Red);
        ball.setPosition(position);
        App.draw(ball);
        App.display();
    }

    return 0;
}
