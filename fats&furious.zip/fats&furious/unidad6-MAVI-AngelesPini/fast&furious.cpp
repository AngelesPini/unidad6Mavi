#include <SFML/Graphics.hpp>
using namespace sf;


int main()
{
    RenderWindow App(VideoMode(800, 600), "Fast & Furious");

    Vector2f position(100.0f, 300.0f);
    float initialSpeed = 2.0f;
    float speed = initialSpeed;
    float speedIncrement = 10.0f;

    while (App.isOpen())
    {
        Event event;
        while (App.pollEvent(event))
        {
            if (event.type == Event::Closed)
                App.close();
        }

 
        float deltaTime = 1.0f / 60.0f; 

        position.x += speed * deltaTime;

        if (position.x > App.getSize().x)
        {

            position.x = -50.0f; 

            speed += speedIncrement;
        }

        App.clear();


        CircleShape object(25.0f);
        object.setPosition(position);
        object.setFillColor(Color::Blue);
        App.draw(object);

        App.display();
    }

    return 0;
}

